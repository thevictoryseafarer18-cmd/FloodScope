#!/usr/bin/env python3
"""Run FloodScope with prepared, pixel-aligned GeoTIFFs and dated OSM GeoJSON.

Example:
  python scripts/run_analysis.py --before before_s1.tif --after after_s1.tif \
    --osm pre_event_osm.geojson --event-date 2026-08-26 --snapshot-date 2026-07-27 \
    --out results/
"""
from __future__ import annotations

import argparse
from datetime import date
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from floodscope.core import analyze
from floodscope.io import mask_geotiff, read_geotiff, read_geojson, result_geojson, result_json
from floodscope.report import build_report


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a transparent flood-screening result from co-registered inputs.")
    parser.add_argument("--before", required=True, help="Pre-event Sentinel-1 GeoTIFF: VV,VH,[dataMask]")
    parser.add_argument("--after", required=True, help="Post-event Sentinel-1 GeoTIFF: VV,VH,[dataMask]")
    parser.add_argument("--osm", required=True, help="Pre-event OSM GeoJSON, WGS84")
    parser.add_argument("--event-date", required=True, help="YYYY-MM-DD")
    parser.add_argument("--snapshot-date", required=True, help="OSM snapshot date, strictly before the event")
    parser.add_argument("--scale", choices=["auto", "linear", "db"], default="auto", help="S1 band units")
    parser.add_argument("--before-s2", help="Optional aligned S2 GeoTIFF: Green,NIR,SCL,[dataMask]")
    parser.add_argument("--after-s2", help="Optional aligned S2 GeoTIFF: Green,NIR,SCL,[dataMask]")
    parser.add_argument("--out", default="results", help="Output folder")
    args = parser.parse_args()
    if bool(args.before_s2) != bool(args.after_s2):
        parser.error("--before-s2 and --after-s2 must be supplied together")

    before, bmeta = read_geotiff(Path(args.before).read_bytes())
    after, ameta = read_geotiff(Path(args.after).read_bytes())
    if bmeta["transform"] != ameta["transform"] or str(bmeta["crs"]) != str(ameta["crs"]) or before.shape != after.shape:
        parser.error("S1 inputs must share shape, transform and CRS")
    optical_pre = optical_post = None
    if args.before_s2:
        optical_pre, sm0 = read_geotiff(Path(args.before_s2).read_bytes())
        optical_post, sm1 = read_geotiff(Path(args.after_s2).read_bytes())
        for meta, arr in ((sm0, optical_pre), (sm1, optical_post)):
            if meta["transform"] != bmeta["transform"] or str(meta["crs"]) != str(bmeta["crs"]) or arr.shape[1:] != before.shape[1:]:
                parser.error("S2 inputs must already be aligned to the S1 grid")
    features = read_geojson(Path(args.osm).read_bytes())
    result = analyze(
        before, after, bmeta["transform"], bmeta["crs"], features,
        event_date=date.fromisoformat(args.event_date), snapshot_date=date.fromisoformat(args.snapshot_date),
        source_scale=args.scale, before_s2=optical_pre, after_s2=optical_post,
        metadata={"source": "User-prepared co-registered Sentinel GeoTIFFs + pre-event OSM GeoJSON"},
    )
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "floodscope_result.json").write_bytes(result_json(result))
    (out / "floodscope_layers.geojson").write_bytes(result_geojson(result))
    (out / "situation_report_en.md").write_text(build_report(result, "English"), encoding="utf-8")
    (out / "water_candidate_mask.tif").write_bytes(mask_geotiff(result))
    (out / "surface_change_watch_mask.tif").write_bytes(mask_geotiff(result, "change_mask"))
    print(json.dumps(result["summary"], indent=2, ensure_ascii=False))
    print(f"\nWrote outputs to {out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
