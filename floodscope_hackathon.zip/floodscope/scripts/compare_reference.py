#!/usr/bin/env python3
"""Offline-only reference comparison. Never imported by the live detector.

The reviewer supplies a published reference polygon solely to score an already
saved mask. Do not feed the reference file to FloodScope's analysis pipeline or
tune thresholds on the held-out judging AOI.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform_geom


def main() -> int:
    parser = argparse.ArgumentParser(description="Score a saved candidate mask against an independent reference polygon layer (validation only).")
    parser.add_argument("--mask", required=True, help="FloodScope water-candidate GeoTIFF (1=candidate)")
    parser.add_argument("--reference", required=True, help="Reviewer-provided EMSR927/reference-only GeoJSON")
    parser.add_argument("--out", default="reference_score.json")
    args = parser.parse_args()
    with rasterio.open(args.mask) as src:
        pred = src.read(1) == 1
        transform = src.transform
        crs = src.crs
        if crs is None:
            parser.error("Mask must have a CRS")
        shapes = []
        with open(args.reference, "r", encoding="utf-8") as handle:
            ref_data = json.load(handle)
        feats = ref_data.get("features", []) if ref_data.get("type") == "FeatureCollection" else [ref_data]
        for feature in feats:
            geom = feature.get("geometry")
            if not geom:
                continue
            source_crs = "EPSG:4326"
            if ref_data.get("crs") and ref_data["crs"].get("properties", {}).get("name"):
                source_crs = ref_data["crs"]["properties"]["name"]
            projected = transform_geom(source_crs, crs, geom, antimeridian_cutting=True, precision=6)
            shapes.append((projected, 1))
        if not shapes:
            parser.error("Reference file has no polygon geometries")
        truth = rasterize(shapes, out_shape=pred.shape, transform=transform, fill=0, dtype="uint8", all_touched=True).astype(bool)
    tp = int(np.logical_and(pred, truth).sum())
    fp = int(np.logical_and(pred, ~truth).sum())
    fn = int(np.logical_and(~pred, truth).sum())
    union = tp + fp + fn
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    report = {
        "use": "validation only; reference was not an inference input",
        "pixels": {"true_positive": tp, "false_positive": fp, "false_negative": fn},
        "metrics": {"intersection_over_union": tp / union if union else 1.0, "precision": precision, "recall": recall, "f1": f1},
        "warning": "These pixel metrics depend on reference legend, georegistration, scale and rasterization choices; they do not measure structural damage or life-safety performance.",
    }
    Path(args.out).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
