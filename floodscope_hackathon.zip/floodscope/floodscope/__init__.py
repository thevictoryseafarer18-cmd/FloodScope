"""FloodScope: transparent flood-screening prototype."""
__version__ = "0.1.0"
