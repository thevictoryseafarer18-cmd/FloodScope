"""Raster/vector upload readers and lightweight exports."""
from __future__ import annotations

import io
import json
from typing import Any

import numpy as np
import rasterio
from rasterio.io import MemoryFile


def read_geotiff(upload: Any) -> tuple[np.ndarray, dict[str, Any]]:
    """Read an uploaded GeoTIFF as float32 bands and return its georeferencing."""
    raw = upload.getvalue() if hasattr(upload, "getvalue") else upload
    with MemoryFile(raw) as mem:
        with mem.open() as src:
            arr = src.read(out_dtype="float32")
            if src.crs is None:
                raise ValueError("Uploaded GeoTIFF has no CRS.")
            nodata = src.nodata
            if nodata is not None:
                arr[np.isclose(arr, nodata)] = np.nan
            return arr, {
                "transform": src.transform,
                "crs": src.crs,
                "width": src.width,
                "height": src.height,
                "count": src.count,
                "nodata": nodata,
            }


def read_geojson(upload: Any) -> list[dict[str, Any]]:
    raw = upload.getvalue() if hasattr(upload, "getvalue") else upload
    payload = json.loads(raw.decode("utf-8") if isinstance(raw, (bytes, bytearray)) else raw)
    if payload.get("type") == "FeatureCollection":
        features = payload.get("features", [])
    elif payload.get("type") == "Feature":
        features = [payload]
    else:
        raise ValueError("OSM upload must be a GeoJSON Feature or FeatureCollection.")
    return [f for f in features if f.get("geometry")]


def result_json(result: dict[str, Any]) -> bytes:
    payload = {
        "product": "FloodScope screening result",
        "metadata": result.get("metadata", {}),
        "summary": result.get("summary", {}),
        "network": result.get("network", {}),
        "layers": result.get("layers", {}),
        "limitations": [
            "Candidate detections are not field-verified flood, debris, structural damage, or road closure.",
            "Himalayan relief can cause radar shadow/layover; thresholds and OSM coverage vary by place.",
            "Road graph is simplified and only tests connectivity to mapped OSM town/hospital features.",
            "A Sentinel revisit cannot warn of a sudden event minutes ahead.",
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2, default=str).encode("utf-8")


def result_geojson(result: dict[str, Any]) -> bytes:
    features = []
    for layer_name, collection in (result.get("layers") or {}).items():
        for feat in (collection or {}).get("features", []):
            row = dict(feat)
            row["properties"] = dict(row.get("properties") or {})
            row["properties"]["floodscope_layer"] = layer_name
            features.append(row)
    return json.dumps({"type": "FeatureCollection", "features": features}, ensure_ascii=False, default=str).encode("utf-8")


def mask_geotiff(result: dict[str, Any], layer: str = "water_mask") -> bytes:
    internal = result["internal"]
    arr = internal[layer].astype(np.uint8)
    profile = {
        "driver": "GTiff",
        "height": int(internal["height"]),
        "width": int(internal["width"]),
        "count": 1,
        "dtype": "uint8",
        "crs": internal["crs"],
        "transform": internal["transform"],
        "nodata": 0,
        "compress": "deflate",
    }
    with MemoryFile() as mem:
        with mem.open(**profile) as dst:
            dst.write(arr, 1)
            dst.update_tags(1, description=layer, note="Candidate screening output; 1 = candidate; not confirmed damage")
        return mem.read()
