"""Core, offline flood-screening logic for FloodScope.

The output is a screening product, not a damage confirmation. The SAR rules are
transparent thresholds over co-registered Sentinel-1 backscatter; optional
Sentinel-2 NDWI is independent corroboration, not a trained segmentation model.
"""
from __future__ import annotations

from collections import Counter
from datetime import date
import math
from typing import Any, Iterable

import networkx as nx
import numpy as np
from pyproj import CRS, Transformer
from rasterio import features as rio_features
from rasterio.transform import Affine, array_bounds
from scipy import ndimage
from scipy.spatial import cKDTree
from shapely.geometry import (
    GeometryCollection,
    LineString,
    MultiLineString,
    MultiPoint,
    MultiPolygon,
    Point,
    Polygon,
    box,
    mapping,
    shape,
)
from shapely.ops import transform as geom_transform, unary_union


WGS84 = CRS.from_epsg(4326)


def _scale_to_db(a: np.ndarray, scale: str = "auto") -> tuple[np.ndarray, bool]:
    """Return dB data plus whether the input was interpreted as linear power."""
    arr = np.asarray(a, dtype=np.float32)
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        return np.full(arr.shape, np.nan, dtype=np.float32), False
    mode = scale.lower()
    if mode == "auto":
        # Sentinel Hub FLOAT32 S1 output is linear power, normally < 1. A dB
        # GeoTIFF normally contains negative values. Users can override this.
        p95 = float(np.nanpercentile(finite, 95))
        linear = bool(float(np.nanmin(finite)) >= 0 and p95 <= 1.5)
    elif mode in ("linear", "linear power"):
        linear = True
    elif mode in ("db", "decibel", "decibels"):
        linear = False
    else:
        raise ValueError("scale must be 'auto', 'linear', or 'db'.")
    if linear:
        out = np.full(arr.shape, np.nan, dtype=np.float32)
        ok = np.isfinite(arr) & (arr > 0)
        out[ok] = 10.0 * np.log10(arr[ok])
        return out, True
    return arr, False


def _clean_small_components(mask: np.ndarray, min_pixels: int = 3) -> np.ndarray:
    mask = np.asarray(mask, dtype=bool)
    if not mask.any():
        return mask.copy()
    labels, count = ndimage.label(mask, structure=np.ones((3, 3), dtype=np.uint8))
    sizes = np.bincount(labels.ravel())
    keep = sizes >= max(1, int(min_pixels))
    keep[0] = False
    return keep[labels]


def _mask_polygons(mask: np.ndarray, transform: Affine) -> list[Any]:
    """Polygonize a boolean mask in the raster CRS."""
    if not np.asarray(mask, dtype=bool).any():
        return []
    out: list[Any] = []
    for geom_json, value in rio_features.shapes(
        np.asarray(mask, dtype=np.uint8),
        mask=np.asarray(mask, dtype=bool),
        transform=transform,
        connectivity=8,
    ):
        if int(value) == 1:
            geom = shape(geom_json)
            if not geom.is_empty:
                out.append(geom)
    return out


def _safe_union(geoms: Iterable[Any]) -> Any:
    geoms = [g for g in geoms if g is not None and not g.is_empty]
    return unary_union(geoms) if geoms else GeometryCollection()


def _features(polygons: Iterable[Any], props: dict[str, Any], tx: Transformer) -> dict[str, Any]:
    features = []
    for i, geom in enumerate(polygons, 1):
        try:
            wgs = geom_transform(tx.transform, geom)
            features.append({
                "type": "Feature",
                "id": f"{props.get('layer', 'mask')}-{i}",
                "properties": dict(props),
                "geometry": mapping(wgs),
            })
        except Exception:
            continue
    return {"type": "FeatureCollection", "features": features}


def _properties(feature: dict[str, Any]) -> dict[str, Any]:
    props = feature.get("properties") or {}
    tags = props.get("tags")
    if isinstance(tags, dict):
        merged = dict(tags)
        for k, v in props.items():
            if k not in ("tags",) and not str(k).startswith("@"):
                merged.setdefault(k, v)
        return merged
    return {k: v for k, v in props.items() if not str(k).startswith("@")}


def _categories(tags: dict[str, Any]) -> set[str]:
    cats: set[str] = set()
    building = tags.get("building")
    if building and str(building).lower() not in ("no", "false", "0"):
        cats.add("building")
    if tags.get("highway"):
        cats.add("road")
    if tags.get("bridge") and str(tags.get("bridge")).lower() not in ("no", "false", "0"):
        cats.add("bridge")
    if tags.get("man_made") == "bridge":
        cats.add("bridge")
    if tags.get("amenity") == "hospital" or tags.get("healthcare") == "hospital":
        cats.add("hospital")
    place = str(tags.get("place", "")).lower()
    if place in {"village", "hamlet", "isolated_dwelling", "locality", "suburb", "neighbourhood"}:
        cats.add("settlement")
    if place in {"town", "city"}:
        cats.update({"settlement", "town_service"})
    return cats


def _label(tags: dict[str, Any], categories: set[str], idx: int) -> str:
    name = tags.get("name") or tags.get("name:en") or tags.get("name:ne")
    if name:
        return str(name)
    main = next(iter(sorted(categories)), "feature")
    return f"Unnamed {main} {idx}"


def _to_raster_geometry(geom_json: dict[str, Any], tx: Transformer) -> Any:
    geom = shape(geom_json)
    if geom.is_empty:
        return geom
    try:
        if not geom.is_valid:
            geom = geom.buffer(0)
        return geom_transform(tx.transform, geom)
    except Exception:
        return GeometryCollection()


def _point_for(geom: Any) -> Point | None:
    if geom is None or geom.is_empty:
        return None
    if isinstance(geom, Point):
        return geom
    try:
        return geom.representative_point()
    except Exception:
        return None


def _lines(geom: Any) -> list[LineString]:
    if isinstance(geom, LineString):
        return [geom]
    if isinstance(geom, MultiLineString):
        return list(geom.geoms)
    if isinstance(geom, GeometryCollection):
        out: list[LineString] = []
        for g in geom.geoms:
            out.extend(_lines(g))
        return out
    return []


def _geom_to_geojson(geom: Any, tx: Transformer) -> dict[str, Any] | None:
    if geom is None or geom.is_empty:
        return None
    try:
        return mapping(geom_transform(tx.transform, geom))
    except Exception:
        return None


def _raster_xy_to_pixel(geom: Any, transform: Affine) -> Any:
    inv = ~transform
    return geom_transform(lambda x, y, z=None: (inv.a * x + inv.b * y + inv.c, inv.d * x + inv.e * y + inv.f), geom)


def _feature_collection(items: list[dict[str, Any]]) -> dict[str, Any]:
    return {"type": "FeatureCollection", "features": items}


def _network_assessment(
    records: list[dict[str, Any]],
    flood_union: Any,
    pixel_size_m: float,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Remove road micro-segments intersecting water candidates and test access.

    OSM is topologically simplified from line vertices. A water overlap is only
    a potential blockage; it does not prove a road or bridge has failed.
    """
    graph_before = nx.Graph()
    graph_after = nx.Graph()
    road_buffer = flood_union.buffer(max(2.0, pixel_size_m * 0.25)) if not flood_union.is_empty else GeometryCollection()
    projected_road_features = [r for r in records if "road" in r["categories"]]
    blocked_edges = 0
    total_edges = 0

    def node_key(x: float, y: float) -> tuple[float, float]:
        return (round(float(x), 1), round(float(y), 1))

    for rec in projected_road_features:
        for line in _lines(rec["geom"]):
            coords = list(line.coords)
            for a, b in zip(coords[:-1], coords[1:]):
                if math.hypot(b[0] - a[0], b[1] - a[1]) < 0.2:
                    continue
                seg = LineString([a, b])
                u, v = node_key(*a[:2]), node_key(*b[:2])
                if u == v:
                    continue
                length = float(seg.length)
                is_blocked = bool(not road_buffer.is_empty and seg.intersects(road_buffer))
                graph_before.add_edge(u, v, length=length)
                if is_blocked:
                    blocked_edges += 1
                else:
                    graph_after.add_edge(u, v, length=length)
                total_edges += 1
    graph_after.add_nodes_from(graph_before.nodes)

    services: list[tuple[tuple[float, float], str, str]] = []
    settlements: list[dict[str, Any]] = []
    for rec in records:
        geom = rec["geom"]
        cats = rec["categories"]
        point = _point_for(geom)
        if point is None:
            continue
        if "hospital" in cats:
            services.append((node_key(point.x, point.y), rec["name"], "hospital"))
        if "town_service" in cats:
            services.append((node_key(point.x, point.y), rec["name"], "town/city"))
        if "settlement" in cats and rec["inside_aoi"]:
            settlements.append(rec)

    road_nodes = list(graph_before.nodes)
    max_snap_m = max(250.0, pixel_size_m * 10.0)
    road_tree = cKDTree(np.asarray(road_nodes, dtype=np.float64)) if road_nodes else None

    def nearest_road_node(point: Point) -> tuple[float, float] | None:
        if road_tree is None:
            return None
        distance, idx = road_tree.query([point.x, point.y], k=1)
        if float(distance) > max_snap_m:
            return None
        return road_nodes[int(idx)]

    snapped_services: list[tuple[tuple[float, float], str, str]] = []
    for service_node, name, kind in services:
        p = Point(service_node)
        snapped = nearest_road_node(p)
        if snapped is not None:
            snapped_services.append((snapped, name, kind))
    service_nodes = list(dict.fromkeys([s[0] for s in snapped_services]))

    if graph_before.number_of_nodes() and service_nodes:
        try:
            nearest_dist, nearest_paths = nx.multi_source_dijkstra(graph_before, service_nodes, weight="length")
        except Exception:
            nearest_dist, nearest_paths = {}, {}
    else:
        nearest_dist, nearest_paths = {}, {}
    post_components = list(nx.connected_components(graph_after)) if graph_after.number_of_nodes() else []
    post_component_by_node: dict[Any, int] = {}
    for component_id, component in enumerate(post_components):
        for node in component:
            post_component_by_node[node] = component_id
    service_components = {post_component_by_node.get(s) for s in service_nodes}
    service_components.discard(None)

    assessed: list[dict[str, Any]] = []
    for rec in settlements:
        p = _point_for(rec["geom"])
        snapped = nearest_road_node(p) if p is not None else None
        item = {
            "name": rec["name"],
            "osm_id": rec["osm_id"],
            "baseline_connected": False,
            "potentially_cut_off": False,
            "nearest_service_lost": False,
            "nearest_service": None,
            "status": "not assessed",
        }
        if snapped is None or snapped not in nearest_dist:
            item["status"] = "no mapped baseline route to a town or hospital"
        else:
            path = nearest_paths.get(snapped, [])
            target = path[0] if path else None
            target_service = next((s for s in snapped_services if s[0] == target), None)
            item["baseline_connected"] = True
            item["nearest_service"] = target_service[1] if target_service else None
            item["baseline_route_km"] = round(float(nearest_dist[snapped]) / 1000.0, 2)
            component_id = post_component_by_node.get(snapped)
            reachable_any = component_id is not None and component_id in service_components
            nearest_lost = target is not None and post_component_by_node.get(target) != component_id
            item["potentially_cut_off"] = not reachable_any
            item["nearest_service_lost"] = bool(nearest_lost)
            if not reachable_any:
                item["status"] = "potentially cut off by water-overlap road candidates"
            elif nearest_lost:
                item["status"] = "nearest mapped service disconnected; alternate service remains reachable"
            else:
                item["status"] = "mapped service route remains in the candidate network"
        assessed.append(item)

    cut_off_names = [x["name"] for x in assessed if x["potentially_cut_off"]]
    nearest_lost_names = [x["name"] for x in assessed if x["nearest_service_lost"]]
    summary = {
        "road_graph_edges": int(total_edges),
        "water_overlap_road_edges_removed": int(blocked_edges),
        "settlements_assessed": int(sum(bool(x["baseline_connected"]) for x in assessed)),
        "settlements_not_assessed": int(sum(not bool(x["baseline_connected"]) for x in assessed)),
        "potentially_cut_off_settlements": int(len(cut_off_names)),
        "nearest_service_disconnected_settlements": int(len(nearest_lost_names)),
        "potentially_cut_off_names": cut_off_names,
        "nearest_service_disconnected_names": nearest_lost_names,
        "settlement_routes": assessed,
        "network_note": (
            "Road edges intersecting the water-candidate mask were removed for a screening-only connectivity test. "
            "The graph is simplified from OSM geometry; closures and isolation are not field-verified."
        ),
    }
    return assessed, summary


def analyze(
    before_s1: np.ndarray,
    after_s1: np.ndarray,
    transform: Affine,
    crs: Any,
    osm_features: list[dict[str, Any]] | None = None,
    *,
    event_date: str | date | None = None,
    snapshot_date: str | date | None = None,
    source_scale: str = "auto",
    before_s2: np.ndarray | None = None,
    after_s2: np.ndarray | None = None,
    metadata: dict[str, Any] | None = None,
    min_component_pixels: int = 3,
) -> dict[str, Any]:
    """Run flood screening on two co-registered S1 stacks and optional S2 stacks.

    S1 band order is VV, VH, [optional dataMask]. S2 band order is Green,
    NIR, SCL, [optional dataMask]. The imagery must share one projected grid.
    """
    before_s1 = np.asarray(before_s1, dtype=np.float32)
    after_s1 = np.asarray(after_s1, dtype=np.float32)
    if before_s1.ndim != 3 or after_s1.ndim != 3 or before_s1.shape[0] < 2 or after_s1.shape[0] < 2:
        raise ValueError("Sentinel-1 inputs must be 3-D stacks with at least VV and VH bands.")
    if before_s1.shape != after_s1.shape:
        raise ValueError("Before/after Sentinel-1 rasters must have identical band count and shape.")
    if before_s1.shape[1] < 5 or before_s1.shape[2] < 5:
        raise ValueError("Raster is too small for change screening (minimum 5 x 5 pixels).")
    transform = transform if isinstance(transform, Affine) else Affine(*transform)
    raster_crs = CRS.from_user_input(crs)
    if not raster_crs.is_projected:
        raise ValueError("Use a projected raster CRS (for example local UTM) so area and road lengths are metric.")
    if not isinstance(event_date, (str, date)) or not isinstance(snapshot_date, (str, date)):
        raise ValueError("Both the event date and the pre-event OSM snapshot date are required.")
    event_iso = event_date.isoformat() if isinstance(event_date, date) else str(event_date)[:10]
    snapshot_iso = snapshot_date.isoformat() if isinstance(snapshot_date, date) else str(snapshot_date)[:10]
    try:
        event_value = date.fromisoformat(event_iso)
        snapshot_value = date.fromisoformat(snapshot_iso)
    except ValueError as exc:
        raise ValueError("Event and OSM snapshot dates must use YYYY-MM-DD.") from exc
    if snapshot_value >= event_value:
        raise ValueError("The OSM snapshot must be strictly before the flood date.")

    vv_pre, lin_vv_pre = _scale_to_db(before_s1[0], source_scale)
    vh_pre, lin_vh_pre = _scale_to_db(before_s1[1], source_scale)
    vv_post, lin_vv_post = _scale_to_db(after_s1[0], source_scale)
    vh_post, lin_vh_post = _scale_to_db(after_s1[1], source_scale)
    valid = np.isfinite(vv_pre) & np.isfinite(vh_pre) & np.isfinite(vv_post) & np.isfinite(vh_post)
    for stack in (before_s1, after_s1):
        if stack.shape[0] >= 3:
            valid &= np.isfinite(stack[2]) & (stack[2] > 0)
    # In linear-power inputs, zero/non-positive samples are no-data, not dark water.
    for band_arr, is_linear in ((before_s1[0], lin_vv_pre), (before_s1[1], lin_vh_pre),
                                (after_s1[0], lin_vv_post), (after_s1[1], lin_vh_post)):
        if is_linear:
            valid &= band_arr > 0

    # A small median filter suppresses speckle without hiding broader change.
    vv_pre_f = ndimage.median_filter(vv_pre, size=3, mode="nearest")
    vh_pre_f = ndimage.median_filter(vh_pre, size=3, mode="nearest")
    vv_post_f = ndimage.median_filter(vv_post, size=3, mode="nearest")
    vh_post_f = ndimage.median_filter(vh_post, size=3, mode="nearest")
    delta_vv = vv_post_f - vv_pre_f
    delta_vh = vh_post_f - vh_pre_f

    # Transparent S1 water-candidate rule. It emphasizes new dark water and
    # omits permanent water; thresholds should be tuned/validated by region.
    sar_water = (
        valid
        & (vv_post_f <= -14.5)
        & (delta_vv <= -2.5)
        & ((vh_post_f <= -17.0) | (delta_vh <= -2.0))
    )
    sar_water = _clean_small_components(sar_water, min_component_pixels)
    change_watch = valid & ((np.abs(delta_vv) >= 3.5) | (np.abs(delta_vh) >= 4.0))
    change_watch &= ~sar_water
    change_watch = _clean_small_components(change_watch, min_component_pixels)

    optical_water = np.zeros_like(sar_water, dtype=bool)
    optical_valid = np.zeros_like(sar_water, dtype=bool)
    optical_input_provided = before_s2 is not None and after_s2 is not None
    if optical_input_provided:
        before_s2 = np.asarray(before_s2, dtype=np.float32)
        after_s2 = np.asarray(after_s2, dtype=np.float32)
        if before_s2.ndim != 3 or after_s2.ndim != 3 or before_s2.shape[0] < 3 or after_s2.shape[0] < 3:
            raise ValueError("Sentinel-2 stacks must contain Green, NIR, and SCL bands.")
        if before_s2.shape[1:] != sar_water.shape or after_s2.shape[1:] != sar_water.shape:
            raise ValueError("Optional Sentinel-2 rasters must be resampled to the Sentinel-1 grid before analysis.")
        g0, n0, scl0 = before_s2[0], before_s2[1], before_s2[2]
        g1, n1, scl1 = after_s2[0], after_s2[1], after_s2[2]
        valid_classes = np.isin(scl0.astype(np.int16), [4, 5, 6, 7]) & np.isin(scl1.astype(np.int16), [4, 5, 6, 7])
        if before_s2.shape[0] >= 4:
            valid_classes &= (before_s2[3] > 0)
        if after_s2.shape[0] >= 4:
            valid_classes &= (after_s2[3] > 0)
        den0, den1 = g0 + n0, g1 + n1
        ndwi0 = np.divide(g0 - n0, den0, out=np.zeros_like(g0), where=np.abs(den0) > 1e-6)
        ndwi1 = np.divide(g1 - n1, den1, out=np.zeros_like(g1), where=np.abs(den1) > 1e-6)
        optical_valid = valid_classes & np.isfinite(ndwi0) & np.isfinite(ndwi1)
        optical_water = optical_valid & (ndwi1 >= 0.15) & ((ndwi1 - ndwi0) >= 0.12)
        optical_water = _clean_small_components(optical_water, min_component_pixels)

    combined_water = sar_water | optical_water
    corroborated = sar_water & optical_water
    combined_water = _clean_small_components(combined_water, min_component_pixels)
    change_only = change_watch & ~combined_water

    h, w = sar_water.shape
    pixel_area_m2 = abs(float(transform.a * transform.e - transform.b * transform.d))
    if not math.isfinite(pixel_area_m2) or pixel_area_m2 <= 0:
        raise ValueError("Raster affine transform has an invalid pixel area.")
    pixel_size_m = math.sqrt(pixel_area_m2)
    water_area_m2 = float(combined_water.sum()) * pixel_area_m2
    sar_area_m2 = float(sar_water.sum()) * pixel_area_m2
    optical_area_m2 = float(optical_water.sum()) * pixel_area_m2
    corroborated_area_m2 = float(corroborated.sum()) * pixel_area_m2
    change_area_m2 = float(change_only.sum()) * pixel_area_m2

    water_polys = _mask_polygons(combined_water, transform)
    change_polys = _mask_polygons(change_only, transform)
    water_union = _safe_union(water_polys)
    change_union = _safe_union(change_polys)

    to_wgs = Transformer.from_crs(raster_crs, WGS84, always_xy=True)
    from_wgs = Transformer.from_crs(WGS84, raster_crs, always_xy=True)
    bounds = array_bounds(h, w, transform)
    footprint = box(*bounds)
    footprint_wgs = geom_transform(to_wgs.transform, footprint)

    water_fc = _features(water_polys, {"layer": "water_candidate", "meaning": "SAR and/or optical new-water candidate; not ground-verified"}, to_wgs)
    change_fc = _features(change_polys, {"layer": "surface_change_watch", "meaning": "large Sentinel-1 backscatter change; possible debris or unrelated change"}, to_wgs)

    records: list[dict[str, Any]] = []
    layers: dict[str, list[dict[str, Any]]] = {"roads": [], "buildings": [], "settlements": [], "services": [], "exposed": []}
    feature_counts = Counter()
    exposure_counts = Counter()
    water_buffer = water_union.buffer(max(2.0, pixel_size_m * 0.20)) if not water_union.is_empty else GeometryCollection()
    change_buffer = change_union.buffer(max(2.0, pixel_size_m * 0.20)) if not change_union.is_empty else GeometryCollection()
    for idx, feat in enumerate(osm_features or [], 1):
        geom_json = feat.get("geometry")
        if not geom_json:
            continue
        geom_r = _to_raster_geometry(geom_json, from_wgs)
        if geom_r.is_empty:
            continue
        tags = _properties(feat)
        cats = _categories(tags)
        if not cats:
            continue
        inside = bool(geom_r.intersects(footprint))
        name = _label(tags, cats, idx)
        props = feat.get("properties") or {}
        osm_id = props.get("@osmId") or props.get("osm_id") or feat.get("id")
        rec = {"geom": geom_r, "tags": tags, "categories": cats, "name": name,
               "osm_id": str(osm_id) if osm_id is not None else None, "inside_aoi": inside}
        records.append(rec)

        if not inside:
            continue
        for cat in cats:
            feature_counts[cat] += 1
        is_water = bool(not water_buffer.is_empty and geom_r.intersects(water_buffer))
        is_change = bool(not change_buffer.is_empty and geom_r.intersects(change_buffer))
        water_len = 0.0
        change_len = 0.0
        if "road" in cats:
            try:
                water_len = float(geom_r.intersection(water_buffer).length) if not water_buffer.is_empty else 0.0
                change_len = float(geom_r.intersection(change_buffer).length) if not change_buffer.is_empty else 0.0
            except Exception:
                pass
            is_water = is_water and (water_len >= max(3.0, pixel_size_m * 0.30) or geom_r.geom_type not in ("LineString", "MultiLineString"))
            is_change = is_change and (change_len >= max(3.0, pixel_size_m * 0.30) or geom_r.geom_type not in ("LineString", "MultiLineString"))
        exposure = "water candidate" if is_water else ("surface-change watch" if is_change else "none")
        if "building" in cats:
            exposure_counts["building_water"] += int(is_water)
            exposure_counts["building_change"] += int(is_change and not is_water)
        if "road" in cats:
            exposure_counts["road_water"] += int(is_water)
            exposure_counts["road_change"] += int(is_change and not is_water)
        if "bridge" in cats:
            exposure_counts["bridge_water"] += int(is_water)
        if "road" in cats:
            layer = "roads"
        elif "hospital" in cats or "town_service" in cats:
            layer = "services"
        elif "settlement" in cats:
            layer = "settlements"
        elif "building" in cats:
            layer = "buildings"
        else:
            layer = "buildings"
        geom_wgs = _geom_to_geojson(geom_r, to_wgs)
        if geom_wgs:
            display_props = {
                "name": name,
                "kind": ", ".join(sorted(cats)),
                "exposure": exposure,
                "water_overlap_m": round(water_len, 1),
                "change_overlap_m": round(change_len, 1),
                "osm_id": rec["osm_id"],
                "tags": {str(k): str(v) for k, v in tags.items() if v is not None},
            }
            output_feat = {"type": "Feature", "id": rec["osm_id"] or f"osm-{idx}",
                           "properties": display_props, "geometry": geom_wgs}
            # Cap the map payload for large city AOIs while keeping full metrics/graph.
            if len(layers[layer]) < 2500:
                layers[layer].append(output_feat)
            if exposure != "none" and len(layers["exposed"]) < 5000:
                layers["exposed"].append(output_feat)

    route_rows, network_summary = _network_assessment(records, water_union, pixel_size_m)
    route_by_id = {r.get("osm_id"): r for r in route_rows if r.get("osm_id")}
    for feature in layers["settlements"]:
        route = route_by_id.get(feature.get("id")) or route_by_id.get(feature["properties"].get("osm_id"))
        if route:
            feature["properties"]["network_status"] = route["status"]
            feature["properties"]["potentially_cut_off"] = route["potentially_cut_off"]
            feature["properties"]["nearest_service"] = route["nearest_service"]

    valid_pixel_count = int(valid.sum())
    optical_valid_count = int(optical_valid.sum())
    optical_coverage_pct = round(100.0 * optical_valid_count / max(1, valid_pixel_count), 1)
    total_buildings = int(feature_counts["building"])
    exposed_buildings = int(exposure_counts["building_water"])
    change_buildings = int(exposure_counts["building_change"])
    total_roads = int(feature_counts["road"])
    exposed_roads = int(exposure_counts["road_water"])
    change_roads = int(exposure_counts["road_change"])
    bridges = [r for r in records if "bridge" in r["categories"] and r["inside_aoi"]]
    exposed_bridges = int(exposure_counts["bridge_water"])
    area_km2 = pixel_area_m2 * h * w / 1_000_000.0

    meta = dict(metadata or {})
    meta.update({
        "event_date": event_iso,
        "osm_snapshot_date": snapshot_iso,
        "crs": raster_crs.to_string(),
        "raster_width": int(w),
        "raster_height": int(h),
        "pixel_size_m": round(pixel_size_m, 2),
        "input_scale": source_scale,
        "optical_sentinel2_input_provided": bool(optical_input_provided),
        "optical_sentinel2_used": bool(optical_valid_count > 0),
        "optical_valid_pixel_count": optical_valid_count,
        "optical_valid_coverage_percent": optical_coverage_pct,
    })
    summary = {
        "event_date": event_iso,
        "osm_snapshot_date": snapshot_iso,
        "analysis_area_km2": round(area_km2, 2),
        "valid_pixel_count": valid_pixel_count,
        "water_candidate_area_ha": round(water_area_m2 / 10_000.0, 2),
        "sar_water_candidate_area_ha": round(sar_area_m2 / 10_000.0, 2),
        "optical_water_candidate_area_ha": round(optical_area_m2 / 10_000.0, 2),
        "corroborated_water_area_ha": round(corroborated_area_m2 / 10_000.0, 2),
        "optical_valid_coverage_percent": optical_coverage_pct,
        "surface_change_watch_area_ha": round(change_area_m2 / 10_000.0, 2),
        "building_features_in_snapshot": total_buildings,
        "buildings_overlapping_water_candidate": int(exposed_buildings),
        "buildings_overlapping_change_watch": int(change_buildings),
        "road_features_in_snapshot": total_roads,
        "road_features_overlapping_water_candidate": int(exposed_roads),
        "road_features_overlapping_change_watch": int(change_roads),
        "bridge_features_in_aoi": int(len(bridges)),
        "bridges_overlapping_water_candidate": int(exposed_bridges),
        "mapped_settlement_features_in_aoi": int(len([r for r in records if "settlement" in r["categories"] and r["inside_aoi"]])),
        "mapped_hospitals_and_town_services": int(len([r for r in records if ("hospital" in r["categories"] or "town_service" in r["categories"]) ])),
        "potentially_cut_off_settlements": network_summary["potentially_cut_off_settlements"],
        "nearest_service_disconnected_settlements": network_summary["nearest_service_disconnected_settlements"],
        "potentially_cut_off_names": network_summary["potentially_cut_off_names"],
        "nearest_service_disconnected_names": network_summary["nearest_service_disconnected_names"],
        "settlements_assessed": network_summary["settlements_assessed"],
        "settlements_not_assessed": network_summary["settlements_not_assessed"],
        "road_graph_edges_removed": network_summary["water_overlap_road_edges_removed"],
        "road_graph_edges_total": network_summary["road_graph_edges"],
        "screening_status": "candidate detections; not field-verified damage",
    }

    return {
        "metadata": meta,
        "summary": summary,
        "network": network_summary,
        "layers": {
            "water_candidates": water_fc,
            "surface_change_watch": change_fc,
            **{key: _feature_collection(val) for key, val in layers.items()},
        },
        "internal": {
            "sar_water_mask": sar_water,
            "optical_water_mask": optical_water,
            "water_mask": combined_water,
            "corroborated_mask": corroborated,
            "change_mask": change_only,
            "valid_mask": valid,
            "after_vv_db": np.where(valid, vv_post_f, np.nan),
            "delta_vv_db": np.where(valid, delta_vv, np.nan),
            "delta_vh_db": np.where(valid, delta_vh, np.nan),
            "transform": transform,
            "crs": raster_crs.to_string(),
            "height": h,
            "width": w,
        },
    }
