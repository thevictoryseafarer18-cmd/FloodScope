"""Evidence-bounded bilingual situation reports and question answering.

No language model is used: numeric statements are inserted only from the
analysis result object. The small intent router deliberately abstains outside
its supported map questions.
"""
from __future__ import annotations

from typing import Any


ATTRIBUTIONS = [
    "Contains modified Copernicus Sentinel data 2026.",
    "Produced using Copernicus WorldDEM-30 © DLR e.V. 2010–2014 and © Airbus Defence and Space GmbH 2014–2018 provided under COPERNICUS by the European Union and ESA; all rights reserved.",
    "© OpenStreetMap contributors.",
]


def _summary(result: dict[str, Any]) -> dict[str, Any]:
    return result.get("summary", {})


def _meta(result: dict[str, Any]) -> dict[str, Any]:
    return result.get("metadata", {})


def _num(summary: dict[str, Any], key: str, default: Any = 0) -> Any:
    value = summary.get(key, default)
    return default if value is None else value


def _names(summary: dict[str, Any], key: str = "potentially_cut_off_names") -> list[str]:
    val = summary.get(key, [])
    return [str(x) for x in val] if isinstance(val, (list, tuple)) else []


def build_report(result: dict[str, Any], language: str = "English", *, is_demo: bool = False) -> str:
    """Build a one-page Markdown brief using only map outputs/input metadata."""
    s, m = _summary(result), _meta(result)
    lang = language.lower()
    synthetic = bool(is_demo or m.get("synthetic_demo"))
    demo_banner = "\n> **SYNTHETIC DEMONSTRATION ONLY — not Trishuli observations and not for response decisions.**\n" if synthetic else ""
    water = _num(s, "water_candidate_area_ha", 0)
    change = _num(s, "surface_change_watch_area_ha", 0)
    buildings = _num(s, "buildings_overlapping_water_candidate", 0)
    roads = _num(s, "road_features_overlapping_water_candidate", 0)
    bridges = _num(s, "bridges_overlapping_water_candidate", 0)
    cutoff = _num(s, "potentially_cut_off_settlements", 0)
    assessed = _num(s, "settlements_assessed", 0)
    not_assessed = _num(s, "settlements_not_assessed", 0)
    event = str(s.get("event_date", "not set"))
    snapshot = str(s.get("osm_snapshot_date", "not set"))
    s1_pre = m.get("sentinel1_before", {}) or {}
    s1_post = m.get("sentinel1_after", {}) or {}
    pre_dt = (s1_pre.get("datetime") or "not provided")[:10]
    post_dt = (s1_post.get("datetime") or "not provided")[:10]
    orbit = s1_pre.get("relative_orbit")
    if synthetic:
        orbit_line = "Synthetic fixture; no real orbit metadata."
        date_line_en = f"**Challenge-date label (not an analysis of this event):** {event}  ·  **OSM snapshot label (fictional):** {snapshot}"
        date_line_ne = f"**चुनौती मिति (यस घटनाको वास्तविक विश्लेषण होइन):** {event}  ·  **काल्पनिक OSM स्न्यापसट लेबल:** {snapshot}"
        evidence_line_en = "Fixture provenance: invented radar-like arrays and fictional map features; no Sentinel scene, Copernicus DEM or OSM snapshot was accessed. The dates above are labels only."
        evidence_line_ne = "Fixture provenance: काल्पनिक radar-जस्ता arrays र map features; कुनै वास्तविक Sentinel scene, Copernicus DEM वा OSM स्न्यापसट पहुँच गरिएको छैन। माथिका मितिहरू label मात्र हुन्।"
        optical_line_en = "No Sentinel-2 data were used in the synthetic fixture."
        case_status = m.get("reference_comparison_status", "Not applicable: synthetic fixture; no EMSR927 comparison.")
        attribution_note_en = "**Required challenge attribution block for a future real-data submission; the synthetic fixture contains none of these source data.**"
        attribution_note_ne = "**वास्तविक स्रोत-डेटाका लागि आवश्यक challenge attribution block; synthetic fixture मा यी स्रोत-डेटा छैनन्।**"
    else:
        orbit_line = (f"Same relative orbit {orbit} ({s1_pre.get('orbit_direction', 'direction not supplied')})."
                      if orbit is not None else "Orbit metadata not supplied; verify image comparability.")
        date_line_en = f"**Event date:** {event}  ·  **Pre-event OSM snapshot:** {snapshot}"
        date_line_ne = f"**घटना मिति:** {event}  ·  **पूर्व-घटना OSM स्न्यापसट:** {snapshot}"
        evidence_line_en = f"Sentinel-1 acquisitions: {pre_dt} → {post_dt}. {orbit_line}"
        evidence_line_ne = f"Sentinel-1 अघि/पछि: {pre_dt} → {post_dt}; {orbit_line}"
        optical_line_en = (
            f"Sentinel-2 cloud-masked evidence was used; valid-pixel coverage is {m.get('optical_valid_coverage_percent', 0)}%."
            if m.get("optical_sentinel2_used") else "No usable Sentinel-2 pixels were used; this screening is Sentinel-1-led."
        )
        case_status = m.get("reference_comparison_status", "Not run: EMSR927 was not supplied to the detection pipeline.")
        attribution_note_en = ""
        attribution_note_ne = ""
    water_set = ", ".join(_names(s)) or "No settlement names were flagged as potentially isolated."
    optical_line_ne = "Sentinel-2 optical change cloud/SCL masking सहित थपिएको छ।" if (not synthetic and m.get("optical_sentinel2_used")) else ("Sentinel-2 का उपयोगी pixel उपलब्ध भएनन्; यो Sentinel-1-आधारित screening हो।" if not synthetic else "Synthetic fixture मा Sentinel-2 data प्रयोग गरिएको छैन।")
    osm_line_ne = ("काल्पनिक fixture मा वास्तविक OSM snapshot लिइएको छैन।" if synthetic else f"OSM डेटा घटना अघि: {snapshot}।")
    attribution_block = "\n".join(ATTRIBUTIONS)

    if lang.startswith("nep"):
        return f"""# बाढी अवस्था प्रतिवेदन — FloodScope
{demo_banner}
{date_line_ne}

## नक्साबाट प्राप्त संकेत
- **नयाँ पानीको सम्भावित क्षेत्र:** {water} हेक्टर। यो उम्मेदवार क्षेत्र हो, पुष्टि भएको डुबान होइन।
- **सतह परिवर्तन निगरानी क्षेत्र:** {change} हेक्टर। यसमा मलबा हुन सक्छ, तर अन्य जमिन परिवर्तन पनि हुन सक्छ।
- **पानी उम्मेदवारसँग overlap भएका OSM भवन:** {buildings}; **सडक खण्ड:** {roads}; **पुल:** {bridges}। यी सम्भावित exposure हुन्, प्रमाणित क्षति होइनन्।
- **कुनै म्याप गरिएको सहर/अस्पतालसम्म सम्भावित सडक पहुँच नभएका बस्ती:** {cutoff}। नेटवर्कमा जाँचिएका बस्ती: {assessed}; आधारभूत मार्ग नपाइएका/जाँच्न नसकिएका: {not_assessed}.
- **सम्भावित रूपमा अलग देखिएका बस्ती:** {water_set}

## प्रमाण र सावधानी
{evidence_line_ne} {optical_line_ne}
{osm_line_ne}
Copernicus EMS/UNOSAT वा घटना-पछिका OSM सम्पादनहरू detection input का रूपमा प्रयोग गरिएको छैन। **EMSR927 तुलना:** {case_status}

यो दूरसंवेदी screening prototype हो। बादल, राडार shadow/layover, हिमाली relief, स्थायी नदी, मापन threshold, OSM अपूर्णता, raster pixel को आकार र सरलीकृत सडक graph ले false positive/negative दिन सक्छन्। यसले भवनको संरचनात्मक अवस्था, मृत्यु/हराएका व्यक्ति वा सुरक्षित मार्ग पुष्टि गर्दैन। मैदानबाट पुष्टि नगरी उद्धार/निकासी निर्णयका लागि प्रयोग नगर्नुहोस्।

{attribution_note_ne}
{attribution_block}
"""
    evidence_block = f"{evidence_line_en} {optical_line_en}\n"
    if not synthetic:
        evidence_block += f"OSM was queried at the pre-event snapshot date {snapshot}. Published Copernicus EMS/UNOSAT maps and post-event OSM edits are not detection inputs. **EMSR927 comparison:** {case_status}"
    else:
        evidence_block += f"No EMSR927 data were used. **EMSR927 comparison:** {case_status}"
    return f"""# Flood Situation Brief — FloodScope
{demo_banner}
{date_line_en}

## Map-derived indicators
- **New-water candidate area:** {water} ha. This is a satellite screening candidate, not confirmed inundation.
- **Surface-change watch area:** {change} ha. It may include debris, but also unrelated land-surface change.
- **OSM buildings overlapping water candidates:** {buildings}; **road features:** {roads}; **bridges:** {bridges}. These are potential exposures, not confirmed damage.
- **Settlements with no candidate road route to a mapped town/hospital:** {cutoff}. Settlements assessed in the network: {assessed}; not assessable from the supplied graph: {not_assessed}.
- **Potentially isolated settlement names:** {water_set}

## Evidence and caution
{evidence_block}

This is a remote-sensing screening prototype. Clouds, radar shadow/layover, Himalayan relief, permanent water, threshold choices, OSM incompleteness, pixel size and the simplified road graph can produce false positives or misses. It cannot confirm structural damage, account for deaths/missing people, or certify a safe route. Do not use it for evacuation or dispatch without field verification.

{attribution_note_en}
{attribution_block}
"""


def answer_question(question: str, result: dict[str, Any], language: str = "English") -> str:
    """Small bilingual intent router with a strict map-facts-only response."""
    q = (question or "").strip().lower()
    s = _summary(result)
    nepali = language.lower().startswith("nep") or any(ch in question for ch in "अआइईउऊकखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह")
    water = _num(s, "water_candidate_area_ha", 0)
    change = _num(s, "surface_change_watch_area_ha", 0)
    buildings = _num(s, "buildings_overlapping_water_candidate", 0)
    roads = _num(s, "road_features_overlapping_water_candidate", 0)
    bridges = _num(s, "bridges_overlapping_water_candidate", 0)
    cutoff = _num(s, "potentially_cut_off_settlements", 0)
    names = _names(s)
    names_text = ", ".join(names) if names else ("कुनै नाम flag भएन" if nepali else "no names were flagged")

    intent = None
    if any(x in q for x in ("cut off", "cut-off", "isolat", "reachable", "road connection", "access", "काटिएको", "पहुँच", "अलग")):
        intent = "access"
    elif any(x in q for x in ("bridge", "पुल")):
        intent = "bridge"
    elif any(x in q for x in ("building", "structure", "घर", "भवन", "क्षति")):
        intent = "buildings"
    elif any(x in q for x in ("debris", "change", "मलबा", "परिवर्तन")):
        intent = "change"
    elif any(x in q for x in ("flood", "water", "area", "पानी", "बाढी", "क्षेत्र")):
        intent = "water"

    if nepali:
        if intent == "access":
            return f"नक्सा-आधारित graph परीक्षणमा {cutoff} बस्तीमा कुनै म्याप गरिएको सहर/अस्पतालसम्म सम्भावित सडक मार्ग छैन। नाम: {names_text}। यो पानीसँग overlap भएका सडक हटाएर गरिएको screening हो; जमिनमा पुष्टि आवश्यक छ।"
        if intent == "bridge":
            return f"{bridges} OSM पुल पानी उम्मेदवारसँग overlap भएका छन्। यो सम्भावित exposure हो, पुल भत्किएको प्रमाण होइन।"
        if intent == "buildings":
            return f"{buildings} OSM भवन पानी उम्मेदवारसँग overlap भएका छन्। थप {change} हेक्टर सतह-परिवर्तन क्षेत्र छुट्टै review गर्नुपर्ने छ; यसले संरचनात्मक क्षति पुष्टि गर्दैन।"
        if intent == "change":
            return f"{change} हेक्टर सतह-परिवर्तन watch क्षेत्र नक्सा भएको छ। यसमा मलबा वा अन्य परिवर्तन हुन सक्छ; यो बाढी/मलबाको पुष्टि गरिएको वर्गीकरण होइन।"
        if intent == "water":
            return f"नयाँ पानी उम्मेदवार क्षेत्र {water} हेक्टर छ। यसलाई SAR/optical change thresholds बाट निकालिएको हो; field confirmation आवश्यक छ।"
        return "म हालको नक्साबाट मात्र पानी क्षेत्र, OSM भवन/पुल exposure र सम्भावित settlement connectivity को उत्तर दिन सक्छु। कृपया तीमध्ये एउटा सोध्नुहोस्।"

    if intent == "access":
        return f"The map-derived graph flags {cutoff} settlement(s) with no remaining candidate road route to any mapped town/hospital. Names: {names_text}. This is a water-overlap screening result; verify roads on the ground."
    if intent == "bridge":
        return f"{bridges} OSM bridge feature(s) overlap the water-candidate mask. This is potential exposure, not proof that a bridge failed."
    if intent == "buildings":
        return f"{buildings} OSM building feature(s) overlap water candidates. A further {change} ha is in the surface-change watch layer; neither indicates confirmed structural damage."
    if intent == "change":
        return f"The map contains {change} ha of surface-change watch. It may include debris or unrelated land-surface change; it is not a confirmed debris classification."
    if intent == "water":
        return f"The map contains {water} ha of new-water candidates, derived from pre/post satellite change thresholds. Field confirmation is required."
    return "I can answer only from the current map outputs: water-candidate area, OSM building/bridge exposure, surface change, and settlement connectivity. Ask about one of those; unsupported questions are intentionally not guessed."
