"""Copernicus Data Space and ohsome acquisition helpers.

This module is intentionally independent from the EMS reference maps. EMSR927
is never called here; it belongs only in the separate validation workflow.
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
import math
from typing import Any

import numpy as np
import requests
import rasterio
from pyproj import CRS, Transformer
from rasterio.io import MemoryFile
from rasterio.transform import Affine

TOKEN_URL = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
CATALOG_URL = "https://sh.dataspace.copernicus.eu/catalog/v1/search"
PROCESS_URL = "https://sh.dataspace.copernicus.eu/process/v1"
OHSOME_URL = "https://api.ohsome.org/v1/elements/geometry"
USER_AGENT = "FloodScope-Hackathon-Prototype/0.1 (educational; pre-event OSM only)"

S1_EVALSCRIPT = """//VERSION=3
function setup() {
  return { input: [{ bands: [\"VV\", \"VH\", \"dataMask\"] }],
           output: { bands: 3, sampleType: \"FLOAT32\" } };
}
function evaluatePixel(s) { return [s.VV, s.VH, s.dataMask]; }
"""

S2_EVALSCRIPT = """//VERSION=3
function setup() {
  return { input: [{ bands: [\"B03\", \"B08\", \"SCL\", \"dataMask\"] }],
           output: { bands: 4, sampleType: \"FLOAT32\" } };
}
function evaluatePixel(s) { return [s.B03, s.B08, s.SCL, s.dataMask]; }
"""


def _as_date(value: str | date) -> date:
    return value if isinstance(value, date) else date.fromisoformat(str(value)[:10])


def _iso_utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def get_access_token(client_id: str, client_secret: str, timeout: int = 30) -> str:
    if not client_id.strip() or not client_secret.strip():
        raise ValueError("Enter a Copernicus Data Space OAuth client ID and client secret.")
    response = requests.post(
        TOKEN_URL,
        data={"client_id": client_id.strip(), "client_secret": client_secret.strip(), "grant_type": "client_credentials"},
        headers={"User-Agent": USER_AGENT},
        timeout=timeout,
    )
    if not response.ok:
        raise RuntimeError(f"CDSE OAuth failed ({response.status_code}): {response.text[:600]}")
    token = response.json().get("access_token")
    if not token:
        raise RuntimeError("CDSE token response did not include an access_token.")
    return str(token)


def _catalog_search(token: str, collection: str, bbox: list[float], start: date, end: date, limit: int = 100) -> list[dict[str, Any]]:
    body = {
        "bbox": [float(x) for x in bbox],
        "datetime": f"{start.isoformat()}T00:00:00Z/{end.isoformat()}T23:59:59Z",
        "collections": [collection],
        "limit": min(max(int(limit), 1), 100),
    }
    response = requests.post(
        CATALOG_URL,
        json=body,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json", "User-Agent": USER_AGENT},
        timeout=90,
    )
    if not response.ok:
        raise RuntimeError(f"CDSE catalogue request failed ({response.status_code}): {response.text[:700]}")
    return response.json().get("features", [])


def _item_datetime(item: dict[str, Any]) -> datetime | None:
    raw = (item.get("properties") or {}).get("datetime") or (item.get("properties") or {}).get("start_datetime")
    if not raw:
        return None
    try:
        d = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        return d.replace(tzinfo=timezone.utc) if d.tzinfo is None else d.astimezone(timezone.utc)
    except Exception:
        return None


def _first_property(props: dict[str, Any], keys: tuple[str, ...]) -> Any:
    for key in keys:
        if props.get(key) is not None:
            return props[key]
    return None


def _relative_orbit(props: dict[str, Any]) -> int | None:
    value = _first_property(props, ("s1:relative_orbit", "sat:relative_orbit", "relativeOrbitNumber", "relative_orbit"))
    if value is None:
        return None
    try:
        orbit = int(value)
        return orbit if 1 <= orbit <= 175 else None
    except Exception:
        return None


def _orbit_direction(props: dict[str, Any]) -> str | None:
    value = _first_property(props, ("sat:orbit_state", "sar:orbit_state", "orbitDirection", "orbit_direction"))
    if value is None:
        return None
    value = str(value).upper()
    if value in ("ASCENDING", "DESCENDING"):
        return value
    return None


def _polarization_ok(props: dict[str, Any]) -> bool:
    value = _first_property(props, ("s1:polarization", "sar:polarization", "polarisationChannels", "polarization"))
    if value is None:
        # The Processing API will still enforce DV; allow catalogues which omit it.
        return True
    value = str(value).upper().replace("+", "").replace("&", "").replace(" ", "")
    if value in {"DV", "VVVH", "[\"VV\",\"VH\"]", "['VV','VH']"}:
        return True
    return "VV" in value and "VH" in value


def select_same_track_s1_pair(items: list[dict[str, Any]], event_date: str | date) -> tuple[dict[str, Any], dict[str, Any]]:
    """Choose a before/after pair from one relative orbit and direction.

    The candidate windows exclude event-day ambiguity: pre is before the event
    date, post is after it. Pairing prefers a 12-day separation, as requested in
    the challenge, then minimizes distance from the event.
    """
    day = _as_date(event_date)
    candidates = []
    for item in items:
        props = item.get("properties") or {}
        dt = _item_datetime(item)
        orbit = _relative_orbit(props)
        direction = _orbit_direction(props)
        if not dt or orbit is None or not direction or not _polarization_ok(props):
            continue
        mode = _first_property(props, ("sar:instrument_mode", "instrumentMode", "operationalMode"))
        if mode and str(mode).upper() not in ("IW", "INTERFEROMETRIC WIDE"):
            continue
        candidates.append((item, dt, orbit, direction, props.get("platform") or props.get("platformShortName")))
    pres = [x for x in candidates if x[1].date() < day and (day - x[1].date()).days <= 24]
    posts = [x for x in candidates if x[1].date() > day and (x[1].date() - day).days <= 24]
    pairs = []
    for pre in pres:
        for post in posts:
            if pre[2] != post[2] or pre[3] != post[3]:
                continue
            gap = (post[1].date() - pre[1].date()).days
            if not 8 <= gap <= 17:
                continue
            # Prefer identical platform if available; orbit/direction is the
            # primary co-registration condition, same platform is only a tie-break.
            same_platform_penalty = 0 if pre[4] == post[4] else 1
            score = (abs(gap - 12), same_platform_penalty,
                     abs((day - pre[1].date()).days - 7), (post[1].date() - day).days,
                     pre[1], post[1])
            pairs.append((score, pre, post))
    if not pairs:
        raise RuntimeError(
            "No pre/post Sentinel-1 GRD pair was found on the same relative orbit and direction "
            "within 24 days of the event (with an 8–17 day pair gap). Try a wider AOI/date window or another event date."
        )
    _, pre, post = min(pairs, key=lambda x: x[0])
    return pre[0], post[0]


def _estimate_utm_bbox(bbox: list[float]) -> tuple[CRS, list[float], int, int]:
    west, south, east, north = [float(x) for x in bbox]
    if not (-180 <= west < east <= 180 and -80 <= south < north <= 84):
        raise ValueError("AOI must be a non-wrapping WGS84 bbox within UTM latitude coverage.")
    if (east - west) * (north - south) > 10.0:
        raise ValueError("AOI is too large. Split it into tiles or use a tighter flood corridor bbox.")
    mid_lat, mid_lon = (south + north) / 2, (west + east) / 2
    zone = int(math.floor((mid_lon + 180) / 6) + 1)
    epsg = (32600 if mid_lat >= 0 else 32700) + zone
    crs = CRS.from_epsg(epsg)
    tx = Transformer.from_crs(4326, crs, always_xy=True)
    corners = [tx.transform(west, south), tx.transform(west, north), tx.transform(east, south), tx.transform(east, north)]
    x0, x1 = min(x for x, _ in corners), max(x for x, _ in corners)
    y0, y1 = min(y for _, y in corners), max(y for _, y in corners)
    if ((x1 - x0) * (y1 - y0)) / 1_000_000.0 > 5_000:
        raise ValueError("AOI exceeds 5,000 km². Split the corridor into smaller tiles to keep processing and OSM queries tractable.")
    # Limit outputs to about 4 million pixels, retaining 10 m where possible.
    resolution = max(10.0, (x1 - x0) / 2000.0, (y1 - y0) / 2000.0)
    width = max(1, int(math.ceil((x1 - x0) / resolution)))
    height = max(1, int(math.ceil((y1 - y0) / resolution)))
    return crs, [x0, y0, x1, y1], width, height


def _process_tiff(token: str, collection: str, item: dict[str, Any], bbox_utm: list[float], crs: CRS,
                  width: int, height: int, *, cloud_max: float = 50.0) -> tuple[np.ndarray, Affine]:
    dt = _item_datetime(item)
    if dt is None:
        raise RuntimeError("Selected catalogue item has no valid acquisition time.")
    from_time = _iso_utc(dt - timedelta(minutes=4))
    to_time = _iso_utc(dt + timedelta(minutes=4))
    data_filter: dict[str, Any] = {
        "timeRange": {"from": from_time, "to": to_time},
        "mosaickingOrder": "mostRecent",
    }
    if collection == "sentinel-1-grd":
        direction = _orbit_direction(item.get("properties") or {})
        data_filter.update({"acquisitionMode": "IW", "polarization": "DV", "resolution": "HIGH"})
        if direction:
            data_filter["orbitDirection"] = direction
        data_type = "sentinel-1-grd"
        evalscript = S1_EVALSCRIPT
        processing = {
            "orthorectify": True,
            "demInstance": "COPERNICUS_30",
            "backCoeff": "GAMMA0_TERRAIN",
            "speckleFilter": {"type": "LEE", "windowSizeX": 3, "windowSizeY": 3},
        }
        bands = 3
    else:
        data_filter["maxCloudCoverage"] = float(cloud_max)
        data_type = "sentinel-2-l2a"
        evalscript = S2_EVALSCRIPT
        processing = {"upsampling": "NEAREST"}
        bands = 4
    epsg_code = crs.to_epsg()
    if epsg_code is None:
        raise ValueError("Sentinel Hub export needs an EPSG code for the projected AOI CRS.")
    body = {
        "input": {
            "bounds": {"bbox": bbox_utm, "properties": {"crs": f"http://www.opengis.net/def/crs/EPSG/0/{epsg_code}"}},
            "data": [{"type": data_type, "dataFilter": data_filter, "processing": processing}],
        },
        "output": {
            "width": int(width),
            "height": int(height),
            "responses": [{"identifier": "default", "format": {"type": "image/tiff"}}],
        },
        "evalscript": evalscript,
    }
    response = requests.post(
        PROCESS_URL,
        json=body,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json", "User-Agent": USER_AGENT},
        timeout=240,
    )
    if not response.ok:
        raise RuntimeError(f"CDSE Process API failed for {collection} ({response.status_code}): {response.text[:900]}")
    try:
        with MemoryFile(response.content) as mem:
            with mem.open() as src:
                arr = src.read(out_dtype="float32")
                transform = src.transform
                if src.count != bands:
                    raise RuntimeError(f"Expected {bands} output bands from {collection}, received {src.count}.")
                if arr.shape[1:] != (height, width):
                    raise RuntimeError("CDSE response dimensions do not match the requested grid.")
                return arr, transform
    except rasterio.errors.RasterioIOError as exc:
        raise RuntimeError("CDSE Process API response was not a readable GeoTIFF: " + response.text[:500]) from exc


def _find_s2_pair(items: list[dict[str, Any]], event_date: str | date, cloud_max: float = 50.0) -> tuple[dict[str, Any], dict[str, Any]] | None:
    day = _as_date(event_date)
    rows = []
    for item in items:
        dt = _item_datetime(item)
        if dt is None:
            continue
        props = item.get("properties") or {}
        cloud = props.get("eo:cloud_cover", 100)
        try:
            cloud = float(cloud)
        except Exception:
            cloud = 100.0
        if cloud > float(cloud_max):
            continue
        rows.append((item, dt, cloud))
    pre = [x for x in rows if x[1].date() < day and (day - x[1].date()).days <= 24]
    post = [x for x in rows if x[1].date() > day and (x[1].date() - day).days <= 24]
    if not pre or not post:
        return None
    # Favor close, relatively cloud-free acquisitions; unlike S1, optical data
    # need not share an orbit. SCL later masks clouds at pixel level.
    p = min(pre, key=lambda x: (x[2] + 0.7 * (day - x[1].date()).days, x[1]))
    q = min(post, key=lambda x: (x[2] + 0.7 * (x[1].date() - day).days, x[1]))
    return p[0], q[0]


def fetch_satellite_pair(
    bbox: list[float], event_date: str | date, client_id: str, client_secret: str,
    *, include_s2: bool = True, cloud_max: float = 50.0,
) -> dict[str, Any]:
    """Discover/download a same-track S1 pair and optional clear S2 pair."""
    day = _as_date(event_date)
    token = get_access_token(client_id, client_secret)
    crs, bbox_utm, width, height = _estimate_utm_bbox(bbox)
    # Exclude event-day acquisitions to avoid ambiguity about acquisition time.
    s1_items = _catalog_search(token, "sentinel-1-grd", bbox, day - timedelta(days=24), day + timedelta(days=24))
    pre_s1, post_s1 = select_same_track_s1_pair(s1_items, day)
    pre1_arr, tr_pre = _process_tiff(token, "sentinel-1-grd", pre_s1, bbox_utm, crs, width, height)
    post1_arr, tr_post = _process_tiff(token, "sentinel-1-grd", post_s1, bbox_utm, crs, width, height)
    if tr_pre != tr_post:
        raise RuntimeError("Pre/post Sentinel-1 exports returned different grids; refusing pixel-wise comparison.")

    s2_pre_arr = s2_post_arr = None
    s2_metadata: dict[str, Any] = {"used": False, "reason": "not requested"}
    if include_s2:
        try:
            s2_items = _catalog_search(token, "sentinel-2-l2a", bbox, day - timedelta(days=24), day + timedelta(days=24))
            pair = _find_s2_pair(s2_items, day, cloud_max=cloud_max)
            if pair:
                pre2, post2 = pair
                s2_pre_arr, tr_s2a = _process_tiff(token, "sentinel-2-l2a", pre2, bbox_utm, crs, width, height, cloud_max=cloud_max)
                s2_post_arr, tr_s2b = _process_tiff(token, "sentinel-2-l2a", post2, bbox_utm, crs, width, height, cloud_max=cloud_max)
                if tr_s2a != tr_pre or tr_s2b != tr_pre:
                    raise RuntimeError("Sentinel-2 export grid did not align with Sentinel-1; optical confirmation skipped.")
                s2_metadata = {
                    "used": True,
                    "pre_id": pre2.get("id"), "pre_datetime": _item_datetime(pre2).isoformat(),
                    "pre_cloud_cover_percent": (pre2.get("properties") or {}).get("eo:cloud_cover"),
                    "post_id": post2.get("id"), "post_datetime": _item_datetime(post2).isoformat(),
                    "post_cloud_cover_percent": (post2.get("properties") or {}).get("eo:cloud_cover"),
                }
            else:
                s2_metadata = {"used": False, "reason": "No clear pre/post Sentinel-2 pair found in the 24-day search windows."}
        except Exception as exc:
            # SAR remains the cloud-robust primary product; S2 failure does not
            # invalidate a valid S1 pair, but the reason is surfaced to users.
            s2_pre_arr = s2_post_arr = None
            s2_metadata = {"used": False, "reason": f"Sentinel-2 optional step skipped: {exc}"}

    def item_meta(item: dict[str, Any]) -> dict[str, Any]:
        props = item.get("properties") or {}
        return {
            "id": item.get("id"),
            "datetime": _item_datetime(item).isoformat() if _item_datetime(item) else None,
            "relative_orbit": _relative_orbit(props),
            "orbit_direction": _orbit_direction(props),
            "platform": props.get("platform") or props.get("platformShortName"),
        }
    return {
        "before_s1": pre1_arr,
        "after_s1": post1_arr,
        "before_s2": s2_pre_arr,
        "after_s2": s2_post_arr,
        "transform": tr_pre,
        "crs": crs,
        "metadata": {
            "source": "Copernicus Data Space Ecosystem Sentinel Hub Process API",
            "sentinel1_before": item_meta(pre_s1),
            "sentinel1_after": item_meta(post_s1),
            "sentinel1_relative_orbit_matched": _relative_orbit(pre_s1.get("properties") or {}) == _relative_orbit(post_s1.get("properties") or {}),
            "sentinel1_orbit_direction_matched": _orbit_direction(pre_s1.get("properties") or {}) == _orbit_direction(post_s1.get("properties") or {}),
            "sentinel2": s2_metadata,
            "bbox_wgs84": [float(x) for x in bbox],
            "bbox_projected": bbox_utm,
            "resolution_m_approx": round(max((bbox_utm[2] - bbox_utm[0]) / width, (bbox_utm[3] - bbox_utm[1]) / height), 2),
            "width": width, "height": height,
        },
    }


def _buffer_bbox_km(bbox: list[float], km: float = 10.0) -> list[float]:
    west, south, east, north = [float(x) for x in bbox]
    mid_lat = (south + north) / 2.0
    dlat = km / 110.574
    dlon = km / max(1.0, 111.320 * math.cos(math.radians(mid_lat)))
    return [max(-180.0, west - dlon), max(-80.0, south - dlat), min(180.0, east + dlon), min(84.0, north + dlat)]


def fetch_ohsome_snapshot(
    bbox: list[float], snapshot_date: str | date, *, network_buffer_km: float = 10.0,
    timeout: int = 120,
) -> list[dict[str, Any]]:
    """Fetch dated OSM geometries from ohsome, not present-day Overpass.

    Roads, settlement/service nodes may use a padded bbox to permit a route to
    a destination just beyond the image frame. Exposures are counted only for
    features that intersect the raster AOI.
    """
    day = _as_date(snapshot_date)
    query_bbox = _buffer_bbox_km(bbox, max(0.0, float(network_buffer_km)))
    bboxes = ",".join(f"{x:.7f}" for x in query_bbox)
    filters = [
        ("building=*", "buildings"),
        ("highway=* and type:way", "roads"),
        ("bridge=*", "bridges"),
        ("man_made=bridge", "bridges"),
        ("place=village", "settlements"),
        ("place=hamlet", "settlements"),
        ("place=isolated_dwelling", "settlements"),
        ("place=locality", "settlements"),
        ("place=suburb", "settlements"),
        ("place=neighbourhood", "settlements"),
        ("place=town", "services"),
        ("place=city", "services"),
        ("amenity=hospital", "services"),
        ("healthcare=hospital", "services"),
    ]
    headers = {"User-Agent": USER_AGENT}
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for filter_expr, category in filters:
        response = requests.post(
            OHSOME_URL,
            data={"bboxes": bboxes, "time": day.isoformat(), "filter": filter_expr, "properties": "tags", "format": "geojson"},
            headers=headers,
            timeout=timeout,
        )
        if not response.ok:
            raise RuntimeError(f"ohsome failed for '{filter_expr}' ({response.status_code}): {response.text[:700]}")
        payload = response.json()
        for feature in payload.get("features", []):
            props = feature.setdefault("properties", {})
            props.setdefault("source_layer", category)
            raw_id = props.get("@osmId") or feature.get("id")
            key = str(raw_id) if raw_id is not None else f"{category}:{len(result)}"
            # A single OSM element can match multiple queries (hospital/building).
            if key in seen:
                existing = next((f for f in result if str((f.get("properties") or {}).get("@osmId") or f.get("id")) == key), None)
                if existing:
                    existing_props = existing.setdefault("properties", {})
                    existing_props["source_layer"] = ",".join(sorted(set(str(existing_props.get("source_layer", "")).split(",")) | {category}))
                    if "tags" not in existing_props and "tags" in props:
                        existing_props["tags"] = props["tags"]
                continue
            seen.add(key)
            result.append(feature)
    return result
