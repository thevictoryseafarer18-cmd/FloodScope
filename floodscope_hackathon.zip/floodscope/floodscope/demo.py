"""Deterministic synthetic fixture used for the dashboard tour and tests only."""
from __future__ import annotations

import numpy as np
from pyproj import Transformer
from rasterio.transform import Affine
from shapely.geometry import LineString, Point, box, mapping
from shapely.ops import transform as geom_transform

from .core import analyze


def _feature(geom, tags: dict, osm_id: str) -> dict:
    return {
        "type": "Feature",
        "id": osm_id,
        "properties": {"@osmId": osm_id, "tags": tags},
        "geometry": mapping(geom),
    }


def make_demo_result() -> dict:
    """Create a synthetic, deliberately non-operational corridor scene."""
    rows, cols = 220, 360
    rng = np.random.default_rng(23)
    vv_pre = rng.lognormal(mean=np.log(0.075), sigma=0.14, size=(rows, cols)).astype(np.float32)
    vh_pre = rng.lognormal(mean=np.log(0.018), sigma=0.17, size=(rows, cols)).astype(np.float32)
    vv_post = vv_pre * rng.lognormal(mean=0.0, sigma=0.06, size=(rows, cols)).astype(np.float32)
    vh_post = vh_pre * rng.lognormal(mean=0.0, sigma=0.07, size=(rows, cols)).astype(np.float32)

    # Synthetic meandering inundation stripe. The shape is invented and is not
    # digitized from Nepal imagery or an EMSR927 map.
    for col in range(cols):
        center = int(115 + 18 * np.sin(col / 38.0))
        lo, hi = max(0, center - 4), min(rows, center + 5)
        vv_post[lo:hi, col] = rng.uniform(0.0018, 0.0040, hi - lo)
        vh_post[lo:hi, col] = rng.uniform(0.0005, 0.0015, hi - lo)

    # Synthetic high-change patch, shown separately from water candidates.
    vv_post[38:58, 75:112] = rng.uniform(0.17, 0.27, (20, 37))
    vh_post[38:58, 75:112] = rng.uniform(0.055, 0.095, (20, 37))

    transform = Affine(10, 0, 500_000, 0, -10, 3_100_000)
    crs = "EPSG:32645"
    to_wgs = Transformer.from_crs(crs, "EPSG:4326", always_xy=True)

    def point(col: float, row: float) -> Point:
        x = transform.c + (col + 0.5) * transform.a
        y = transform.f + (row + 0.5) * transform.e
        lon, lat = to_wgs.transform(x, y)
        return Point(lon, lat)

    def line(coords: list[tuple[float, float]]) -> LineString:
        pts = []
        for col, row in coords:
            x = transform.c + (col + 0.5) * transform.a
            y = transform.f + (row + 0.5) * transform.e
            pts.append(to_wgs.transform(x, y))
        return LineString(pts)

    def building(col: float, row: float, size: float = 4.0):
        x = transform.c + (col + 0.5) * transform.a
        y = transform.f + (row + 0.5) * transform.e
        local = box(x - size / 2, y - size / 2, x + size / 2, y + size / 2)
        return geom_transform(to_wgs.transform, local)

    features = []
    features.append(_feature(line([(15, 100), (70, 100), (130, 100), (210, 100), (280, 100), (345, 100)]),
                             {"highway": "primary", "name": "Demo valley road"}, "way-demo-road-1"))
    features.append(_feature(line([(35, 100), (35, 155), (70, 180)]),
                             {"highway": "secondary", "name": "Demo north link"}, "way-demo-road-2"))
    features.append(_feature(line([(170, 100), (178, 100)]),
                             {"highway": "primary", "bridge": "yes", "name": "Demo bridge"}, "way-demo-bridge"))

    for i, (name, col, row) in enumerate([
        ("West Hamlet", 70, 100), ("East Hamlet A", 235, 100), ("East Hamlet B", 305, 100),
    ], 1):
        features.append(_feature(point(col, row), {"place": "village", "name": name}, f"node-demo-village-{i}"))
    features.append(_feature(point(28, 100), {"place": "town", "name": "Demo Town"}, "node-demo-town"))
    features.append(_feature(point(22, 104), {"amenity": "hospital", "name": "Demo Hospital"}, "node-demo-hospital"))

    for i, (col, row, name) in enumerate([
        (171, 98, "Creekside store"), (174, 106, "Roadside house"), (195, 112, "Valley house"),
        (82, 73, "Hill house"), (250, 83, "East house"), (116, 147, "North house"),
    ], 1):
        features.append(_feature(building(col, row), {"building": "yes", "name": name}, f"way-demo-building-{i}"))

    before = np.stack([vv_pre, vh_pre, np.ones_like(vv_pre)], axis=0)
    after = np.stack([vv_post, vh_post, np.ones_like(vv_post)], axis=0)
    result = analyze(
        before, after, transform, crs, features,
        event_date="2026-08-26", snapshot_date="2026-07-27", source_scale="linear",
        metadata={
            "source": "Synthetic local fixture generated in FloodScope; no satellite or reference-map data.",
            "sentinel1_before": {"id": "SYNTHETIC-PRE", "datetime": "2026-08-14T00:00:00+00:00", "relative_orbit": "not applicable", "orbit_direction": "not applicable"},
            "sentinel1_after": {"id": "SYNTHETIC-POST", "datetime": "2026-08-26T00:00:00+00:00", "relative_orbit": "not applicable", "orbit_direction": "not applicable"},
            "synthetic_demo": True,
            "reference_comparison_status": "Not applicable: the dashboard fixture is synthetic and does not represent EMSR927.",
        },
    )
    result["metadata"]["synthetic_demo"] = True
    return result
