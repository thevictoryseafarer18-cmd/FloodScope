# Flood Situation Brief — FloodScope

> **SYNTHETIC DEMONSTRATION ONLY — not Trishuli observations and not for response decisions.**

**Challenge-date label (not an analysis of this event):** 2026-08-26  ·  **OSM snapshot label (fictional):** 2026-07-27

## Map-derived indicators
- **New-water candidate area:** 32.4 ha. This is a satellite screening candidate, not confirmed inundation.
- **Surface-change watch area:** 7.36 ha. It may include debris, but also unrelated land-surface change.
- **OSM buildings overlapping water candidates:** 1; **road features:** 3; **bridges:** 1. These are potential exposures, not confirmed damage.
- **Settlements with no candidate road route to a mapped town/hospital:** 1. Settlements assessed in the network: 3; not assessable from the supplied graph: 1.
- **Potentially isolated settlement names:** East Hamlet B

## Evidence and caution
Fixture provenance: invented radar-like arrays and fictional map features; no Sentinel scene, Copernicus DEM or OSM snapshot was accessed. The dates above are labels only. No Sentinel-2 data were used in the synthetic fixture.
No EMSR927 data were used. **EMSR927 comparison:** Not applicable: the dashboard fixture is synthetic and does not represent EMSR927.

This is a remote-sensing screening prototype. Clouds, radar shadow/layover, Himalayan relief, permanent water, threshold choices, OSM incompleteness, pixel size and the simplified road graph can produce false positives or misses. It cannot confirm structural damage, account for deaths/missing people, or certify a safe route. Do not use it for evacuation or dispatch without field verification.

**Required challenge attribution block for a future real-data submission; the synthetic fixture contains none of these source data.**
Contains modified Copernicus Sentinel data 2026.
Produced using Copernicus WorldDEM-30 © DLR e.V. 2010–2014 and © Airbus Defence and Space GmbH 2014–2018 provided under COPERNICUS by the European Union and ESA; all rights reserved.
© OpenStreetMap contributors.
