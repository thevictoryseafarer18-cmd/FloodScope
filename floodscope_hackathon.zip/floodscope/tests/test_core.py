from datetime import date

import numpy as np
import pytest
from rasterio.transform import from_origin

from floodscope.core import analyze
from floodscope.demo import make_demo_result
from floodscope.sources import select_same_track_s1_pair


def _item(day, relative_orbit=42, direction="ASCENDING", platform="SENTINEL-1A"):
    return {
        "id": f"item-{day}",
        "properties": {
            "datetime": f"{day}T05:00:00Z",
            "relativeOrbitNumber": relative_orbit,
            "orbitDirection": direction,
            "polarisationChannels": "VV&VH",
            "operationalMode": "IW",
            "platformShortName": platform,
        },
    }


def test_same_track_pair_prefers_twelve_day_gap():
    items = [
        _item("2026-08-14"),
        _item("2026-08-26"),  # event date is excluded
        _item("2026-08-26", relative_orbit=43),
        _item("2026-08-31"),
    ]
    before, after = select_same_track_s1_pair(items, date(2026, 8, 26))
    assert before["id"] == "item-2026-08-14"
    assert after["id"] == "item-2026-08-31"


def test_no_pair_across_tracks():
    with pytest.raises(RuntimeError, match="same relative orbit"):
        select_same_track_s1_pair([
            _item("2026-08-14", relative_orbit=42),
            _item("2026-08-31", relative_orbit=43),
        ], date(2026, 8, 26))


def test_demo_is_labeled_and_has_candidates():
    result = make_demo_result()
    assert result["metadata"]["synthetic_demo"] is True
    assert result["summary"]["water_candidate_area_ha"] > 0
    assert result["summary"]["surface_change_watch_area_ha"] > 0
    assert result["summary"]["potentially_cut_off_settlements"] >= 1
    assert result["summary"]["event_date"] == "2026-08-26"


def test_osm_snapshot_must_precede_event():
    before = np.ones((2, 12, 12), dtype=np.float32) * 0.08
    after = before.copy()
    with pytest.raises(ValueError, match="strictly before"):
        analyze(before, after, from_origin(500000, 3100000, 10, 10), "EPSG:32645", [],
                event_date="2026-08-26", snapshot_date="2026-08-26", source_scale="linear")
